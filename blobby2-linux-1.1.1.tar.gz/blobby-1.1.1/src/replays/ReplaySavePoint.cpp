/*=============================================================================
Blobby Volley 2
Copyright (C) 2006 Jonathan Sieber (jonathan_sieber@yahoo.de)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
=============================================================================*/

#include "ReplaySavePoint.h"

#include <climits>

#include "GenericIO.h"

const unsigned int REPLAY_STEP_EMPTY = UINT_MAX;

USER_SERIALIZER_IMPLEMENTATION_HELPER(ReplaySavePoint)
{
	io.template generic<DuelMatchState> (value.state);
	io.uint32(value.step);
}

void ReplaySavePoint::reset()
{
	step = REPLAY_STEP_EMPTY;
}

bool ReplaySavePoint::isEmpty() const { return step == REPLAY_STEP_EMPTY; }
